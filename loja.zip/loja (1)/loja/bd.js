

// Função para cadastrar um novo usuário
function cadastrarUsuario(nome, login, telefone, email, senha) {
  let dados = JSON.parse(localStorage.getItem("tds")) || [];
  let novoUsuario = {
    "id": dados.length + 1,
    "nome": nome,
    "login": login,
    "telefone": telefone,
    "email": email,
    "senha": senha
  };
  dados.push(novoUsuario);
  localStorage.setItem("tds", JSON.stringify(dados));
  return novoUsuario;
}

// Função para buscar um usuário pelo nome de usuário (login)
function buscarUsuarioPorLogin(login) {
  let dados = JSON.parse(localStorage.getItem("tds")) || [];
  return dados.find(usuario => usuario.login === login);
}

// Função para verificar as credenciais de login
function verificarCredenciais(login, senha) {
  let usuario = buscarUsuarioPorLogin(login);
  return usuario && usuario.senha === senha;
}

document.addEventListener("DOMContentLoaded", function() {
  // Event listener para o formulário de registro
  document.getElementById("registroForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let nome = document.getElementById("nome").value;
    let login = document.getElementById("login").value;
    let telefone = document.getElementById("telefone").value;
    let email = document.getElementById("email").value;
    let senha = document.getElementById("senha").value;

    if (!buscarUsuarioPorLogin(login)) {
        cadastrarUsuario(nome, login, telefone, email, senha);
        alert("Usuário registrado com sucesso!");
        window.location.href = "login.html"; // Redireciona para a página de login
    } else {
        alert("O nome de usuário já está em uso. Por favor, escolha outro.");
    }
  });

  // Event listener para o formulário de login
  document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let login = document.getElementById("login").value;
    let senha = document.getElementById("senha").value;

    if (verificarCredenciais(login, senha)) {
        alert("Login bem-sucedido!");
        // Redirecionamento para a página inicial após o login
        window.location.href = "index.html";
    } else {
        alert("Nome de usuário ou senha incorretos. Por favor, tente novamente.");
    }
  });
});

// Chamada para inicializar o armazenamento local com dados de exemplo


// Função para inicializar o armazenamento local com alguns dados de exemplo
function inicializarLocalStorage() {
  // Se o armazenamento local não tiver sido inicializado, inicialize-o com os dados de exemplo
  if (!localStorage.getItem("produtos")) {
      const produtos = [
          { id: 1, nome: "Figure Action Goku", preco: 89.90 },
          { id: 2, nome: "Caneca Saiyajin", preco: 29.90 },
          { id: 3, nome: "Camisa do Goku", preco: 49.90 },
          { id: 4, nome: "Mochila Dragon Ball", preco: 79.90 },
          { id: 5, nome: "Figure Action Shen Long", preco: 129.90 },
          { id: 6, nome: "Figure Action Vegeta", preco: 99.90 }
      ];
      localStorage.setItem("produtos", JSON.stringify(produtos));
  }
}

// Função para obter todos os produtos
function obterProdutos() {
  return JSON.parse(localStorage.getItem("produtos")) || [];
}

// Função para calcular o total da compra
function calcularTotalCompra(produtosSelecionados) {
  let total = 0;
  produtosSelecionados.forEach(produto => {
      total += produto.preco;
  });
  return total.toFixed(2); // Arredonda para duas casas decimais
}

document.addEventListener("DOMContentLoaded", function() {
  // Chamada para inicializar o armazenamento local com dados de exemplo
  inicializarLocalStorage();

  // Event listener para o formulário de pagamento
  document.getElementById("pagamentoForm").addEventListener("submit", function(event) {
      event.preventDefault();
      const produtosSelecionados = []; // Array para armazenar os produtos selecionados

      // Loop através dos checkboxes dos produtos para encontrar os produtos selecionados
      document.querySelectorAll('input[type="checkbox"]').forEach(function(checkbox) {
          if (checkbox.checked) {
              const id = parseInt(checkbox.value);
              const produto = obterProdutos().find(p => p.id === id);
              if (produto) {
                  produtosSelecionados.push(produto);
              }
          }
      });

      // Calcular o total da compra
      const totalCompra = calcularTotalCompra(produtosSelecionados);
      alert("Total da compra: R$ " + totalCompra);

      // Aqui você pode adicionar código para processar o pagamento, como enviar os dados para um servidor de pagamento
  });

  // Função para exibir os produtos na página
  function exibirProdutos() {
      const produtos = obterProdutos();
      const container = document.getElementById("listaProdutos");
      container.innerHTML = ""; // Limpar o conteúdo anterior

      produtos.forEach(produto => {
          const div = document.createElement("div");
          div.innerHTML = `
              <input type="checkbox" name="produto" value="${produto.id}">
              <label>${produto.nome} - R$ ${produto.preco.toFixed(2)}</label><br>
          `;
          container.appendChild(div);
      });
  }

  // Chamar a função para exibir os produtos quando a página for carregada
  exibirProdutos();
});

function adicionarAoCarrinho(nome, preco) {
  let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];
  carrinho.push({ nome: nome, preco: preco, quantidade: 1 }); // Adiciona a quantidade inicial como 1
  localStorage.setItem("carrinho", JSON.stringify(carrinho));
  atualizarTotal(); // Chama a função para atualizar o total do carrinho
  alert("Produto adicionado ao carrinho!");
}

// Função para atualizar o valor total do carrinho
function atualizarTotal() {
  let total = 0;
  let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

  carrinho.forEach((produto) => {
    total += produto.preco * produto.quantidade;
  });

  localStorage.setItem("total", total.toFixed(2)); // Salvar o total no localStorage
}

// Função para carregar os produtos do carrinho
function carregarProdutosCarrinho() {
  const carrinhoProdutos = document.getElementById("carrinhoProdutos");
  carrinhoProdutos.innerHTML = ""; // Limpar qualquer conteúdo anterior

  let carrinho = JSON.parse(localStorage.getItem("carrinho")) || [];

  carrinho.forEach((produto, index) => {
    const cardProduto = `
      <div class="col-md-12 mb-3">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">${produto.nome}</h5>
            <p class="card-text">Preço: R$ ${produto.preco.toFixed(2)}</p>
            <p class="card-text">Quantidade: ${produto.quantidade}</p>
            <button class="btn btn-primary" onclick="aumentarQuantidade(${index})">+</button>
            <button class="btn btn-danger" onclick="removerProduto(${index})">Remover</button>
          </div>
        </div>
      </div>
    `;
    carrinhoProdutos.innerHTML += cardProduto;
  });
}